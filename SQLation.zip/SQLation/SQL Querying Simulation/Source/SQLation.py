import csv
import os
import re
import sqlite3
import tkinter as tk
from datetime import datetime
from tkinter import filedialog

# ============================================================
# PYTHON SQL DATABASE SIMULATOR
# ============================================================
#
# FEATURES
# ------------------------------------------------------------
# 1. Launches GUI file picker for selecting .txt SQL setup file.
# 2. Automatically derives table name and DB CSV filename:
#    Table Name      : <setup_file_name>_db
#    DB CSV Filename : <setup_file_name>_db.csv
# 3. Supports CREATE TABLE, INSERT, comments, etc. in setup.
# 4. Creates an in-memory SQLite database.
# 5. Exports the database to <setup_file_name>_db.csv.
# 6. Launches GUI folder dialogs for selecting output directories.
# 7. Provides a terminal SQL interface.
# 8. ONE physical line = ONE query executed immediately on ENTER.
# 9. Supports SELECT / WITH queries including:
#    - GROUP BY and HAVING clauses
#    - Aggregate functions: SUM(), COUNT()
#    - String transformation functions: UPPER(), LOWER()
#    - Sorting: ORDER BY ... ASC / DESC
# 10. Query results are displayed in terminal.
# 11. Every query is exported to:
#     <setup_file_name>_db_query_MM-DD-YYYY.csv
# 12. Existing query CSV for that date is overwritten.
# 13. EXIT terminates the program, case-insensitive.
#
# ============================================================

# ============================================================
# PATH & GUI UTILITIES
# ============================================================
def normalize_path(path):
    """
    Convert a user-entered path into an absolute normalized path.
    """
    return os.path.abspath(
        os.path.expanduser(
            path.strip()
        )
    )


def select_file_gui(title, default_directory, file_types):
    """
    Open a GUI file explorer pop-up to select a file.
    """
    root = tk.Tk()
    root.withdraw()  # Hide main Tkinter window
    root.attributes("-topmost", True)  # Bring pop-up to front

    selected_file = filedialog.askopenfilename(
        title=title,
        initialdir=default_directory,
        filetypes=file_types
    )
    root.destroy()

    if not selected_file:
        return None

    return normalize_path(selected_file)


def select_directory_gui(title, default_directory):
    """
    Open a GUI file explorer pop-up to select a directory.
    Falls back to default_directory if canceled.
    """
    root = tk.Tk()
    root.withdraw()  # Hide main Tkinter window
    root.attributes("-topmost", True)  # Bring pop-up to front

    selected_directory = filedialog.askdirectory(
        title=title,
        initialdir=default_directory
    )
    root.destroy()

    if not selected_directory:
        print(f"No directory selected for '{title}'. Using default: {default_directory}")
        return default_directory

    return normalize_path(selected_directory)


def ensure_directory(directory):
    """
    Make sure the requested directory exists.
    """
    try:
        os.makedirs(
            directory,
            exist_ok=True
        )
    except OSError as error:
        raise RuntimeError(
            f"Could not create/access directory:\n"
            f"{directory}\n\n"
            f"Reason: {error}"
        )


# ============================================================
# SQL COMMENT REMOVAL
# ============================================================
def remove_sql_comments(sql):
    """
    Remove SQL comments while preserving quoted strings.
    Supports:
    -- single-line comments
    /* block comments */
    """
    result = []
    i = 0
    in_single_quote = False
    in_double_quote = False
    while i < len(sql):
        char = sql[i]
        # ----------------------------------------------------
        # Single-quoted string
        # ----------------------------------------------------
        if char == "'" and not in_double_quote:
            if (
                in_single_quote
                and i + 1 < len(sql)
                and sql[i + 1] == "'"
            ):
                result.append("''")
                i += 2
                continue
            in_single_quote = not in_single_quote
            result.append(char)
            i += 1
            continue
        # ----------------------------------------------------
        # Double-quoted identifier
        # ----------------------------------------------------
        if char == '"' and not in_single_quote:
            if (
                in_double_quote
                and i + 1 < len(sql)
                and sql[i + 1] == '"'
            ):
                result.append('""')
                i += 2
                continue
            in_double_quote = not in_double_quote
            result.append(char)
            i += 1
            continue
        # ----------------------------------------------------
        # -- comment
        # ----------------------------------------------------
        if (
            not in_single_quote
            and not in_double_quote
            and char == "-"
            and i + 1 < len(sql)
            and sql[i + 1] == "-"
        ):
            newline_position = sql.find(
                "\n",
                i + 2
            )
            if newline_position == -1:
                break
            result.append("\n")
            i = newline_position + 1
            continue
        # ----------------------------------------------------
        # /* block comment */
        # ----------------------------------------------------
        if (
            not in_single_quote
            and not in_double_quote
            and char == "/"
            and i + 1 < len(sql)
            and sql[i + 1] == "*"
        ):
            end_position = sql.find(
                "*/",
                i + 2
            )
            if end_position == -1:
                raise ValueError(
                    "Unterminated SQL block comment."
                )
            i = end_position + 2
            continue
        # ----------------------------------------------------
        # Normal character
        # ----------------------------------------------------
        result.append(char)
        i += 1
    return "".join(result)


# ============================================================
# SQL WHITESPACE NORMALIZATION
# ============================================================
def normalize_sql_whitespace(sql):
    """
    Normalize whitespace outside quoted strings.
    """
    result = []
    in_single_quote = False
    in_double_quote = False
    pending_space = False
    i = 0
    while i < len(sql):
        char = sql[i]
        # ----------------------------------------------------
        # Single-quoted string
        # ----------------------------------------------------
        if char == "'" and not in_double_quote:
            if (
                in_single_quote
                and i + 1 < len(sql)
                and sql[i + 1] == "'"
            ):
                if pending_space:
                    result.append(" ")
                    pending_space = False
                result.append("''")
                i += 2
                continue
            if pending_space:
                result.append(" ")
                pending_space = False
            in_single_quote = not in_single_quote
            result.append(char)
            i += 1
            continue
        # ----------------------------------------------------
        # Double-quoted identifier
        # ----------------------------------------------------
        if char == '"' and not in_single_quote:
            if (
                in_double_quote
                and i + 1 < len(sql)
                and sql[i + 1] == '"'
            ):
                if pending_space:
                    result.append(" ")
                    pending_space = False
                result.append('""')
                i += 2
                continue
            if pending_space:
                result.append(" ")
                pending_space = False
            in_double_quote = not in_double_quote
            result.append(char)
            i += 1
            continue
        # ----------------------------------------------------
        # Whitespace outside strings
        # ----------------------------------------------------
        if (
            not in_single_quote
            and not in_double_quote
            and char.isspace()
        ):
            pending_space = True
            i += 1
            continue
        # ----------------------------------------------------
        # Normal character
        # ----------------------------------------------------
        if pending_space:
            result.append(" ")
            pending_space = False
        result.append(char)
        i += 1
    return "".join(result).strip()


# ============================================================
# SETUP FILE READER
# ============================================================
def read_setup_file(setup_file):
    """
    Read the setup SQL file.
    """
    try:
        with open(
            setup_file,
            "r",
            encoding="utf-8-sig"
        ) as file:
            return file.read()
    except FileNotFoundError:
        raise RuntimeError(
            f"Setup file does not exist:\n"
            f"{setup_file}"
        )
    except PermissionError:
        raise RuntimeError(
            f"Permission denied:\n"
            f"{setup_file}"
        )
    except OSError as error:
        raise RuntimeError(
            f"Could not read setup file:\n"
            f"{error}"
        )


# ============================================================
# EXECUTE SETUP SQL
# ============================================================
def execute_setup_file(connection, setup_sql):
    """
    Execute the complete setup SQL script.
    """
    try:
        cleaned_sql = remove_sql_comments(
            setup_sql
        )
        connection.executescript(
            cleaned_sql
        )
        connection.commit()
    except ValueError as error:
        connection.rollback()
        raise RuntimeError(
            f"SQL setup parsing error:\n\n{error}"
        )
    except sqlite3.Error as error:
        connection.rollback()
        raise RuntimeError(
            f"SQL setup error:\n\n{error}"
        )


# ============================================================
# DATABASE TABLE LIST
# ============================================================
def get_database_tables(connection):
    """
    Get all user-created tables.
    """
    cursor = connection.cursor()
    return cursor.execute(
        """
        SELECT name
        FROM sqlite_master
        WHERE type = 'table'
        AND name NOT LIKE 'sqlite_%'
        ORDER BY name
        """
    ).fetchall()


# ============================================================
# DATABASE CSV EXPORT
# ============================================================
def export_database_csv(
    connection,
    output_file
):
    """
    Export the database into CSV.
    """
    tables = get_database_tables(
        connection
    )
    if not tables:
        raise RuntimeError(
            "No user-created tables were found."
        )
    try:
        with open(
            output_file,
            "w",
            newline="",
            encoding="utf-8-sig"
        ) as file:
            writer = csv.writer(file)
            cursor = connection.cursor()
            for table_index, table in enumerate(
                tables
            ):
                table_name = table[0]
                # ------------------------------------------------
                # Get table structure
                # ------------------------------------------------
                columns = cursor.execute(
                    f'PRAGMA table_info("{table_name}")'
                ).fetchall()
                column_names = [
                    column[1]
                    for column in columns
                ]
                # ------------------------------------------------
                # Get rows
                # ------------------------------------------------
                rows = cursor.execute(
                    f'SELECT * FROM "{table_name}"'
                ).fetchall()
                # ------------------------------------------------
                # Multiple tables
                # ------------------------------------------------
                if len(tables) > 1:
                    if table_index > 0:
                        writer.writerow([])
                    writer.writerow(
                        [f"TABLE: {table_name}"]
                    )
                # ------------------------------------------------
                # Header
                # ------------------------------------------------
                writer.writerow(
                    column_names
                )
                # ------------------------------------------------
                # Data
                # ------------------------------------------------
                for row in rows:
                    writer.writerow(
                        row
                    )
    except sqlite3.Error as error:
        raise RuntimeError(
            f"Could not read database:\n"
            f"{error}"
        )
    except OSError as error:
        raise RuntimeError(
            f"Could not write database CSV:\n"
            f"{error}"
        )


# ============================================================
# QUERY VALIDATION
# ============================================================
def validate_query(query):
    """
    Validate one query entered into the terminal.
    """
    # --------------------------------------------------------
    # Remove comments
    # --------------------------------------------------------
    try:
        query = remove_sql_comments(
            query
        )
    except ValueError as error:
        return False, str(error)

    # --------------------------------------------------------
    # Normalize whitespace
    # --------------------------------------------------------
    query = normalize_sql_whitespace(
        query
    )

    # --------------------------------------------------------
    # Empty query
    # --------------------------------------------------------
    if not query:
        return False, "Query is empty."

    # --------------------------------------------------------
    # Remove ONE trailing semicolon
    # --------------------------------------------------------
    if query.endswith(";"):
        query = query[:-1].rstrip()
        if not query:
            return False, "Query is empty."

    # --------------------------------------------------------
    # Semicolon outside quotes check
    # --------------------------------------------------------
    if contains_unquoted_semicolon(query):
        return False, (
            "Only one SQL statement is allowed per query."
        )

    # --------------------------------------------------------
    # Determine first SQL keyword
    # --------------------------------------------------------
    match = re.match(
        r"^\s*([A-Za-z_][A-Za-z0-9_]*)",
        query
    )
    if not match:
        return False, (
            "Could not determine the SQL statement type."
        )
    first_keyword = match.group(1).upper()

    # --------------------------------------------------------
    # Read-only query types
    # --------------------------------------------------------
    if first_keyword not in (
        "SELECT",
        "WITH"
    ):
        return False, (
            "Only SELECT and WITH queries are allowed "
            "in query mode."
        )
    return True, query


# ============================================================
# UNQUOTED SEMICOLON DETECTION
# ============================================================
def contains_unquoted_semicolon(sql):
    """
    Determine whether SQL contains an unquoted semicolon.
    """
    in_single_quote = False
    in_double_quote = False
    i = 0
    while i < len(sql):
        char = sql[i]
        # ----------------------------------------------------
        # Single quote
        # ----------------------------------------------------
        if char == "'" and not in_double_quote:
            if (
                in_single_quote
                and i + 1 < len(sql)
                and sql[i + 1] == "'"
            ):
                i += 2
                continue
            in_single_quote = not in_single_quote
            i += 1
            continue
        # ----------------------------------------------------
        # Double quote
        # ----------------------------------------------------
        if char == '"' and not in_single_quote:
            if (
                in_double_quote
                and i + 1 < len(sql)
                and sql[i + 1] == '"'
            ):
                i += 2
                continue
            in_double_quote = not in_double_quote
            i += 1
            continue
        # ----------------------------------------------------
        # Semicolon outside quotes
        # ----------------------------------------------------
        if (
            char == ";"
            and not in_single_quote
            and not in_double_quote
        ):
            return True
        i += 1
    return False


# ============================================================
# QUERY EXECUTION
# ============================================================
def execute_query(
    connection,
    query
):
    """
    Execute one read-only SQL query.
    """
    cursor = connection.cursor()
    try:
        cursor.execute(
            query
        )
        # ----------------------------------------------------
        # Ensure query returned a result set.
        # ----------------------------------------------------
        if cursor.description is None:
            raise RuntimeError(
                "The SQL statement did not return a result set."
            )
        # ----------------------------------------------------
        # Column names
        # ----------------------------------------------------
        column_names = [
            description[0]
            for description in cursor.description
        ]
        # ----------------------------------------------------
        # Rows
        # ----------------------------------------------------
        rows = cursor.fetchall()
        return column_names, rows
    except sqlite3.Error as error:
        raise RuntimeError(
            str(error)
        )


# ============================================================
# TERMINAL RESULT DISPLAY
# ============================================================
def display_query_results(
    column_names,
    rows
):
    """
    Display query results as a simple terminal table.
    """
    print()
    # --------------------------------------------------------
    # No results
    # --------------------------------------------------------
    if not rows:
        print(
            "Query executed successfully."
        )
        print(
            "0 row(s) returned."
        )
        return

    # --------------------------------------------------------
    # Convert values to strings
    # --------------------------------------------------------
    display_rows = []
    for row in rows:
        converted_row = []
        for value in row:
            if value is None:
                converted_row.append(
                    "NULL"
                )
            else:
                converted_row.append(
                    str(value)
                )
        display_rows.append(
            converted_row
        )

    # --------------------------------------------------------
    # Determine column widths
    # --------------------------------------------------------
    widths = []
    for column_index, column_name in enumerate(
        column_names
    ):
        width = len(
            str(column_name)
        )
        for row in display_rows:
            width = max(
                width,
                len(
                    row[column_index]
                )
            )
        widths.append(
            width
        )

    # --------------------------------------------------------
    # Separator
    # --------------------------------------------------------
    separator = "+".join(
        "-" * (width + 2)
        for width in widths
    )

    # --------------------------------------------------------
    # Header
    # --------------------------------------------------------
    header = []
    for index, column_name in enumerate(
        column_names
    ):
        header.append(
            f" {str(column_name):<{widths[index]}} "
        )
    print(
        "+".join(header)
    )
    print(
        separator
    )

    # --------------------------------------------------------
    # Rows
    # --------------------------------------------------------
    for row in display_rows:
        row_output = []
        for index, value in enumerate(
            row
        ):
            row_output.append(
                f" {value:<{widths[index]}} "
            )
        print(
            "+".join(row_output)
        )

    # --------------------------------------------------------
    # Result count
    # --------------------------------------------------------
    print()
    print(
        f"{len(rows)} row(s) returned."
    )


# ============================================================
# QUERY CSV EXPORT
# ============================================================
def export_query_csv(
    column_names,
    rows,
    output_file
):
    """
    Save query results to CSV.
    """
    try:
        with open(
            output_file,
            "w",
            newline="",
            encoding="utf-8-sig"
        ) as file:
            writer = csv.writer(
                file
            )
            # ------------------------------------------------
            # Header
            # ------------------------------------------------
            writer.writerow(
                column_names
            )
            # ------------------------------------------------
            # Rows
            # ------------------------------------------------
            for row in rows:
                writer.writerow(
                    row
                )
    except OSError as error:
        raise RuntimeError(
            f"Could not write query CSV:\n"
            f"{error}"
        )


# ============================================================
# MAIN
# ============================================================
def main():
    print("=" * 70)
    print(
        " PYTHON SQL DATABASE SIMULATOR"
    )
    print("=" * 70)

    # ========================================================
    # SCRIPT DIRECTORY
    # ========================================================
    script_directory = os.path.dirname(
        os.path.abspath(__file__)
    )

    # ========================================================
    # 1. SETUP FILE (GUI POP-UP)
    # ========================================================
    while True:
        print("\nOpening file dialog to select SQL setup file...")
        setup_file = select_file_gui(
            "Select SQL Setup .txt File",
            script_directory,
            [("Text Files", "*.txt"), ("SQL Files", "*.sql"), ("All Files", "*.*")]
        )
        
        if not setup_file:
            print("ERROR: No setup file was selected.")
            retry = input("Try again? (y/n): ").strip().lower()
            if retry != 'y':
                print("Exiting database simulator.")
                return
            continue

        if not os.path.isfile(setup_file):
            print(f"ERROR: File does not exist:\n{setup_file}")
            continue
        
        print(f"Selected setup file: {setup_file}")
        break

    # Determine target table name and database CSV filename format
    setup_file_basename = os.path.splitext(os.path.basename(setup_file))[0]
    target_table_name = f"{setup_file_basename}_db"

    # ========================================================
    # 2. CREATE SQLITE DATABASE & EXECUTE SETUP
    # ========================================================
    connection = sqlite3.connect(
        ":memory:"
    )
    try:
        print()
        print(
            "Loading setup file..."
        )
        setup_sql = read_setup_file(
            setup_file
        )

        execute_setup_file(
            connection,
            setup_sql
        )
        print(
            "Setup executed successfully."
        )

        # ====================================================
        # RENAME CREATED TABLE TO MATCH <filename>_db
        # ====================================================
        tables = get_database_tables(
            connection
        )
        if not tables:
            raise RuntimeError(
                "No user-created tables were found in the setup file."
            )

        old_table_name = tables[0][0]
        if old_table_name != target_table_name:
            cursor = connection.cursor()
            cursor.execute(f'ALTER TABLE "{old_table_name}" RENAME TO "{target_table_name}"')
            connection.commit()

        tables = get_database_tables(connection)
        table_names = [table[0] for table in tables]
        primary_table_name = target_table_name

        # Print detected/renamed table name
        print()
        print(f"Table Name : {primary_table_name}")

        # ====================================================
        # 3. DATABASE CSV DIRECTORY (GUI POP-UP)
        # ====================================================
        print("\nOpening folder dialog to select Database CSV directory...")
        database_directory = select_directory_gui(
            "Select Directory for Database CSV",
            script_directory
        )
        ensure_directory(
            database_directory
        )

        # ====================================================
        # DATABASE CSV NAME (<filename>_db.csv)
        # ====================================================
        database_csv = os.path.join(
            database_directory,
            f"{primary_table_name}.csv"
        )

        # ====================================================
        # EXPORT DATABASE
        # ====================================================
        export_database_csv(
            connection,
            database_csv
        )
        print()
        print(
            "Database CSV created:"
        )
        print(
            database_csv
        )

        # ====================================================
        # 4. QUERY CSV DIRECTORY (GUI POP-UP)
        # ====================================================
        print("\nOpening folder dialog to select Query CSVs directory...")
        query_directory = select_directory_gui(
            "Select Directory for Query CSVs",
            script_directory
        )
        ensure_directory(
            query_directory
        )

        # ====================================================
        # 5. DATABASE READY
        # ====================================================
        print()
        print("=" * 70)
        print(
            " DATABASE READY"
        )
        print("=" * 70)
        print(
            f"Setup file : {setup_file}"
        )
        print(
            f"Table name : {primary_table_name}"
        )
        print(
            f"Database   : {database_csv}"
        )
        print(
            f"Query CSVs : {query_directory}"
        )
        print()
        print(
            "Enter ONE SQL query per line."
        )
        print(
            "Press ENTER to execute immediately."
        )
        print(
            "Supported functions: SELECT, WITH, GROUP BY, HAVING, SUM(), COUNT(), UPPER(), LOWER(), ORDER BY ASC/DESC"
        )
        print(
            "Type EXIT to terminate."
        )
        print("=" * 70)

        # ====================================================
        # 6. QUERY LOOP
        # ====================================================
        while True:
            print()
            user_input = input(
                "SQL> "
            )

            # =================================================
            # EXIT
            # =================================================
            if user_input.strip().lower() == "exit":
                print()
                print(
                    "Exiting database simulator."
                )
                break

            # =================================================
            # VALIDATE QUERY
            # =================================================
            valid, query = validate_query(
                user_input
            )
            if not valid:
                print()
                print(
                    f"ERROR: {query}"
                )
                continue

            # =================================================
            # EXECUTE QUERY
            # =================================================
            try:
                column_names, rows = execute_query(
                    connection,
                    query
                )
            except RuntimeError as error:
                print()
                print(
                    f"SQL ERROR: {error}"
                )
                continue

            # =================================================
            # DISPLAY RESULTS
            # =================================================
            display_query_results(
                column_names,
                rows
            )

            # =================================================
            # CREATE QUERY CSV NAME
            # =================================================
            today = datetime.now().strftime(
                "%m-%d-%Y"
            )
            query_csv = os.path.join(
                query_directory,
                f"{primary_table_name}_query_{today}.csv"
            )

            # =================================================
            # EXPORT QUERY RESULTS
            # =================================================
            try:
                export_query_csv(
                    column_names,
                    rows,
                    query_csv
                )
            except RuntimeError as error:
                print()
                print(
                    f"CSV ERROR: {error}"
                )
                continue

            # =================================================
            # CONFIRMATION
            # =================================================
            print()
            print(
                "Query CSV saved:"
            )
            print(
                query_csv
            )

    # ========================================================
    # ERROR HANDLING
    # ========================================================
    except RuntimeError as error:
        print()
        print("=" * 70)
        print(
            "FATAL ERROR"
        )
        print("=" * 70)
        print(
            error
        )
    except KeyboardInterrupt:
        print()
        print()
        print(
            "Program interrupted by user."
        )
    finally:
        connection.close()


# ============================================================
# PROGRAM ENTRY POINT
# ============================================================
if __name__ == "__main__":
    main()